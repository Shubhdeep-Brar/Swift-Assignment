//
//  main.swift
//  Basic Education Portal
//
//  Created by Shubhdeep on 2022-09-13.
//

import Foundation

func main() {
    
    LoginView.initializingPortal()
    
}

main()
